package com.example.appproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2;
    Button b1;
    TextView b2;
    DatabaseCollect db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //final DatabaseCollect db;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db=new DatabaseCollect(this);
        e1=(EditText)findViewById(R.id.email);
        e2=(EditText)findViewById(R.id.pass);
        //e3=(EditText)findViewById(R.id.cpass);
        b2=(TextView) findViewById(R.id.register);
        b1=(Button) findViewById(R.id.login);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = e1.getText().toString();
                String password = e2.getText().toString();
                Boolean checkemailpass = db.ep(email,password);
                if(checkemailpass == true){
                    Intent i =new Intent(MainActivity.this,Main2Activity.class);
                    startActivity(i);
                }else{
                    Toast.makeText(getApplicationContext(),"password do not match",Toast.LENGTH_SHORT).show();
                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i =new Intent(MainActivity.this,loginpage.class);
                startActivity(i);
            }
        });
    }
}
